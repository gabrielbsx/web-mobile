import React from 'react';
import Navigator from './src/routes';

const App = () => {
  return <Navigator />;
};

export default App;
